# Finance Consultancy Club - IITH

![Finance Consultancy Club](https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)

## About

The Finance Consultancy Club at IIT Hyderabad is a student-led organization dedicated to providing financial literacy, consultancy services, and educational resources to the IITH community and beyond. Our platform connects students with industry experts, provides educational materials, and offers hands-on workshops and events.

## Features

- **Expert Consultations**: Connect with finance industry professionals
- **Educational Resources**: Access to curated articles, videos, and tools
- **Workshops & Events**: Participate in regular learning opportunities
- **Project Showcase**: View real-world finance projects by club members
- **Community Forum**: Engage with peers and mentors on financial topics

## Getting Started

### Prerequisites

- Node.js (v18.0.0 or higher)
- npm (v8.0.0 or higher)

### Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/finance-consultancy-club.git
   cd finance-consultancy-club
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

## Tech Stack

- **React**: Frontend library for building user interfaces
- **TypeScript**: Static typing for JavaScript
- **Vite**: Next-generation frontend tooling
- **TailwindCSS**: Utility-first CSS framework
- **React Router**: Declarative routing for React applications
- **Lucide Icons**: Beautiful, consistent icons

## Project Structure

```
finance-consultancy-club/
├── public/             # Static assets
├── src/
│   ├── assets/         # Images, fonts, etc.
│   ├── components/     # Reusable UI components
│   ├── hooks/          # Custom React hooks
│   ├── layouts/        # Page layout components
│   ├── pages/          # Page components
│   ├── types/          # TypeScript type definitions
│   ├── utils/          # Utility functions
│   ├── App.tsx         # Main application component
│   └── main.tsx        # Application entry point
├── .eslintrc.cjs       # ESLint configuration
├── index.html          # HTML template
├── package.json        # Dependencies and scripts
├── tailwind.config.js  # TailwindCSS configuration
├── tsconfig.json       # TypeScript configuration
└── vite.config.ts      # Vite configuration
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

Finance Consultancy Club - [fcc@iith.ac.in](mailto:fcc@iith.ac.in)

Project Link: [https://github.com/yourusername/finance-consultancy-club](https://github.com/yourusername/finance-consultancy-club)