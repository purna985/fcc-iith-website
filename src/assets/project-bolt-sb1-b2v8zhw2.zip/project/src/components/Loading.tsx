import { CircleNotch } from 'lucide-react'

const Loading = () => {
  return (
    <div className="flex items-center justify-center h-[50vh]">
      <div className="text-center">
        <CircleNotch className="h-12 w-12 text-primary-600 animate-spin mx-auto" />
        <p className="mt-4 text-lg text-gray-600">Loading...</p>
      </div>
    </div>
  )
}

export default Loading