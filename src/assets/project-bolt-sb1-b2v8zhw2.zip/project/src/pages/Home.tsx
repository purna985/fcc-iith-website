import { ArrowRight, BarChart, BookOpen, Calendar, Users } from 'lucide-react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-primary-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Finance Consultancy Club</h1>
              <p className="text-xl md:text-2xl text-gray-100 mb-8">
                Empowering students with financial knowledge and consultancy skills for the future
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/about" className="btn bg-white text-primary-700 hover:bg-gray-100">
                  Learn More
                </Link>
                <Link to="/contact" className="btn bg-accent-400 text-white hover:bg-accent-500">
                  Join Us
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Finance Consultancy" 
                className="rounded-lg shadow-lg animate-slide-up"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What We Offer</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our club provides a comprehensive platform for students interested in finance and consultancy
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="card p-6 text-center">
              <div className="bg-primary-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                <BarChart className="h-7 w-7 text-primary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Financial Analysis</h3>
              <p className="text-gray-600 mb-4">
                Learn to analyze financial data and make informed decisions
              </p>
              <Link to="/services" className="text-primary-700 font-medium hover:text-primary-600 inline-flex items-center">
                Learn more <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div className="card p-6 text-center">
              <div className="bg-primary-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-7 w-7 text-primary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Resources & Learning</h3>
              <p className="text-gray-600 mb-4">
                Access curated educational content and case studies
              </p>
              <Link to="/resources" className="text-primary-700 font-medium hover:text-primary-600 inline-flex items-center">
                Explore resources <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div className="card p-6 text-center">
              <div className="bg-primary-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-7 w-7 text-primary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Events & Workshops</h3>
              <p className="text-gray-600 mb-4">
                Participate in workshops, seminars, and industry interactions
              </p>
              <Link to="/events" className="text-primary-700 font-medium hover:text-primary-600 inline-flex items-center">
                See upcoming events <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>

            <div className="card p-6 text-center">
              <div className="bg-primary-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mx-auto mb-4">
                <Users className="h-7 w-7 text-primary-700" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Networking</h3>
              <p className="text-gray-600 mb-4">
                Connect with peers, alumni, and industry professionals
              </p>
              <Link to="/team" className="text-primary-700 font-medium hover:text-primary-600 inline-flex items-center">
                Meet our team <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-accent-400 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Ready to enhance your financial skills?</h2>
          <p className="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto">
            Join our club today and be part of a community that's shaping future financial leaders
          </p>
          <Link to="/contact" className="btn bg-white text-accent-500 hover:bg-gray-100">
            Join the Club
          </Link>
        </div>
      </section>

      {/* Upcoming Events Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Upcoming Events</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't miss out on our exciting workshops and events
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="card overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/2977565/pexels-photo-2977565.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Workshop on Investment Strategies" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="text-sm text-primary-700 font-medium mb-2">July 15, 2025 • 3:00 PM</div>
                <h3 className="text-xl font-semibold mb-3">Workshop on Investment Strategies</h3>
                <p className="text-gray-600 mb-4">
                  Learn about modern investment approaches and portfolio management techniques.
                </p>
                <Link to="/events" className="btn btn-outline w-full">
                  Register Now
                </Link>
              </div>
            </div>

            <div className="card overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Panel Discussion: Future of FinTech" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="text-sm text-primary-700 font-medium mb-2">July 22, 2025 • 5:00 PM</div>
                <h3 className="text-xl font-semibold mb-3">Panel Discussion: Future of FinTech</h3>
                <p className="text-gray-600 mb-4">
                  Industry experts discuss emerging trends and technologies in financial services.
                </p>
                <Link to="/events" className="btn btn-outline w-full">
                  Register Now
                </Link>
              </div>
            </div>

            <div className="card overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/3182781/pexels-photo-3182781.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Networking Mixer with Alumni" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="text-sm text-primary-700 font-medium mb-2">July 30, 2025 • 6:00 PM</div>
                <h3 className="text-xl font-semibold mb-3">Networking Mixer with Alumni</h3>
                <p className="text-gray-600 mb-4">
                  Connect with successful alumni working in various financial sectors.
                </p>
                <Link to="/events" className="btn btn-outline w-full">
                  Register Now
                </Link>
              </div>
            </div>
          </div>

          <div className="text-center mt-10">
            <Link to="/events" className="btn btn-primary">
              View All Events
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home